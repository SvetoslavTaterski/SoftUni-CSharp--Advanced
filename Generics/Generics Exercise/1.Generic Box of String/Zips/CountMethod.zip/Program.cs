﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _1.Generic_Box_of_String
{
    class Program
    {
        static void Main(string[] args)
        {
            int numberOfCommands = int.Parse(Console.ReadLine());
            Box<string> boxes = new Box<string>();

            for (int i = 0; i < numberOfCommands; i++)
            {
                string command = Console.ReadLine();
                boxes.Items.Add(command);
            }

            string element = Console.ReadLine();

            Console.WriteLine(boxes.Count(element));
        }
    }
}
