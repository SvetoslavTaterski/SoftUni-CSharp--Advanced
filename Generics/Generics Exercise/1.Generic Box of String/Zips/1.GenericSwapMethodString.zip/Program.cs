﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _1.Generic_Box_of_String
{
    class Program
    {
        static void Main(string[] args)
        {
            int numberOfCommands = int.Parse(Console.ReadLine());
            Box<string> boxes = new Box<string>();

            for (int i = 0; i < numberOfCommands; i++)
            {
                string command = Console.ReadLine();
                boxes.Items.Add(command);
            }

            int[] swapCommand = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
            int first = swapCommand[0];
            int second = swapCommand[1];

            boxes.Swap(first, second);

            foreach (var item in boxes.Items)
            {
                Console.WriteLine($"{item.GetType()}: {item}");
            }
        }
    }
}
