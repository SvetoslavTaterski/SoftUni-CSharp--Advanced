﻿using System;

namespace _1.Generic_Box_of_String
{
    class Program
    {
        static void Main(string[] args)
        {
            int numberOfCommands = int.Parse(Console.ReadLine());

            for (int i = 0; i < numberOfCommands; i++)
            {
                string command = Console.ReadLine();
                Box<string> box = new Box<string>(command);
                Console.WriteLine(box.ToString());
            }

        }
    }
}
