﻿using System;

namespace Tuple
{
    public class Program
    {
        static void Main(string[] args)
        {
            string[] nameAndAdress = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            string fullName = nameAndAdress[0] + " " + nameAndAdress[1];
            string addres = nameAndAdress[2];
            TupleClass<string, string> firstTuple = new TupleClass<string, string>(fullName, addres);
            Console.WriteLine(firstTuple);

            string[] nameAndBeerLiters = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            string name = nameAndBeerLiters[0];
            int liters = int.Parse(nameAndBeerLiters[1]);
            TupleClass<string, int> secondTuple = new TupleClass<string, int>(name, liters);
            Console.WriteLine(secondTuple);

            string[] integerAndDouble = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            int integer = int.Parse(integerAndDouble[0]);
            double _double = double.Parse(integerAndDouble[1]);
            TupleClass<int, double> thirdTuple = new TupleClass<int, double>(integer, _double);
            Console.WriteLine(thirdTuple);
        }
    }
}
