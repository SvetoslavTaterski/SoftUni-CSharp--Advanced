﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Person person1 = new Person();
            Person person2 = new Person();
            Person person3 = new Person();

            person1.Name = "Svetoslav";
            person2.Name = "Borislav";
            person3.Name = "Stefan";

            person1.Age = 20;
            person2.Age = 20;
            person3.Age = 21;
        }
    }
}
